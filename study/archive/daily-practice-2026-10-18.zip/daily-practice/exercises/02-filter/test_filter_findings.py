"""filter_findings 的 16 项公开测试；仅使用标准库。"""

import unittest

from findings import filter_findings


class FilterFindingsTests(unittest.TestCase):
    def test_01_default_threshold(self):
        records = [
            {"id": "a", "severity": 0, "message": "Info"},
            {"id": "b", "severity": 1, "message": "Low"},
            {"id": "c", "severity": 2, "message": "Medium"},
            {"id": "d", "severity": 3, "message": "High"},
        ]
        self.assertEqual(filter_findings(records), records[2:])

    def test_02_preserve_original_order(self):
        records = [
            {"id": "z", "severity": 2, "message": "First"},
            {"id": "a", "severity": 3, "message": "Second"},
            {"id": "m", "severity": 1, "message": "Skip"},
            {"id": "b", "severity": 2, "message": "Third"},
        ]
        self.assertEqual(filter_findings(records), [records[0], records[1], records[3]])

    def test_03_threshold_boundaries(self):
        records = [
            {"id": str(level), "severity": level, "message": "Finding"}
            for level in range(4)
        ]
        for threshold in range(4):
            with self.subTest(threshold=threshold):
                self.assertEqual(filter_findings(records, threshold), records[threshold:])

    def test_04_empty_input_returns_new_empty_list(self):
        records = []
        result = filter_findings(records)
        self.assertEqual(result, [])
        self.assertIsNot(result, records)

    def test_05_no_matches_returns_empty_list(self):
        records = [
            {"id": "a", "severity": 0, "message": "Info"},
            {"id": "b", "severity": 1, "message": "Low"},
        ]
        self.assertEqual(filter_findings(records), [])

    def test_06_duplicate_ids_are_preserved(self):
        records = [
            {"id": "same", "severity": 2, "message": "First"},
            {"id": "same", "severity": 3, "message": "Second"},
            {"id": "same", "severity": 2, "message": "First"},
        ]
        self.assertEqual(filter_findings(records), records)

    def test_07_empty_strings_and_unicode_are_valid(self):
        records = [
            {"id": "", "severity": 2, "message": ""},
            {"id": "中文🙂", "severity": 3, "message": "  保留\n大小写 ABC！  "},
        ]
        self.assertEqual(filter_findings(records), records)

    def test_08_input_is_not_modified(self):
        records = [
            {"id": "a", "severity": 1, "message": "Skip"},
            {"id": "b", "severity": 3, "message": "Keep"},
            {"id": "c", "severity": 2, "message": "Also keep"},
        ]
        expected = [record.copy() for record in records]
        original_objects = records.copy()
        filter_findings(records)
        self.assertEqual(records, expected)
        for current, original in zip(records, original_objects):
            self.assertIs(current, original)

    def test_09_returned_list_and_each_dictionary_are_new(self):
        shared = {"id": "same", "severity": 2, "message": "Shared input object"}
        records = [shared, shared]
        result = filter_findings(records)
        self.assertIsInstance(result, list)
        self.assertEqual(result, records)
        self.assertIsNot(result, records)
        for returned in result:
            self.assertIsInstance(returned, dict)
            self.assertIsNot(returned, shared)
        self.assertIsNot(result[0], result[1])

    def test_10_modifying_result_does_not_change_input(self):
        records = [{"id": "a", "severity": 2, "message": "Original"}]
        result = filter_findings(records)
        result[0]["id"] = "changed"
        result[0]["severity"] = 0
        result[0]["message"] = "Changed"
        result[0]["extra"] = "New field"
        result.append({"id": "b", "severity": 3, "message": "New"})
        self.assertEqual(records, [{"id": "a", "severity": 2, "message": "Original"}])

    def test_11_findings_must_be_a_list(self):
        for records in (None, (), {}, "records", 42, True):
            with self.subTest(input_type=type(records).__name__):
                with self.assertRaises(TypeError):
                    filter_findings(records)

    def test_12_each_finding_must_be_a_dictionary(self):
        for record in (None, [], (), "finding", 42, True):
            with self.subTest(record_type=type(record).__name__):
                with self.assertRaises(TypeError):
                    filter_findings([record])

    def test_13_id_and_message_must_be_strings_even_when_filtered_out(self):
        for field in ("id", "message"):
            for value in (None, 42, 1.5, True, [], {}, b"text"):
                with self.subTest(field=field, value_type=type(value).__name__):
                    record = {"id": "a", "severity": 0, "message": "Valid"}
                    record[field] = value
                    with self.assertRaises(TypeError):
                        filter_findings([record], min_severity=2)

    def test_14_fields_must_match_exactly(self):
        valid = {"id": "a", "severity": 2, "message": "Valid"}
        invalid_records = [{}]
        for field in valid:
            record = valid.copy()
            del record[field]
            invalid_records.append(record)
        invalid_records.append({**valid, "extra": "Unexpected"})
        invalid_records.append({"id": "a", "severity": 2, "text": "Wrong field"})
        for record in invalid_records:
            with self.subTest(keys=list(record)):
                with self.assertRaises(ValueError):
                    filter_findings([record])

    def test_15_severity_type_and_range(self):
        for severity in (None, "2", 2.0, True, False, [], {}):
            with self.subTest(severity=severity):
                with self.assertRaises(TypeError):
                    filter_findings([{"id": "a", "severity": severity, "message": "Valid"}])
        for severity in (-1, 4, 100):
            with self.subTest(severity=severity):
                with self.assertRaises(ValueError):
                    filter_findings([{"id": "a", "severity": severity, "message": "Valid"}])

    def test_16_min_severity_type_and_range(self):
        records = [{"id": "a", "severity": 2, "message": "Valid"}]
        for threshold in (None, "2", 2.0, True, False, [], {}):
            with self.subTest(threshold=threshold):
                with self.assertRaises(TypeError):
                    filter_findings(records, min_severity=threshold)
        for threshold in (-1, 4, 100):
            with self.subTest(threshold=threshold):
                with self.assertRaises(ValueError):
                    filter_findings(records, min_severity=threshold)


if __name__ == "__main__":
    unittest.main()
