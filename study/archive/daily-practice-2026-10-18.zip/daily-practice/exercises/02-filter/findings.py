"""筛选发现练习；题目见 ../../题目.md#filter。"""


def filter_findings(
    findings: list[dict[str, object]],
    min_severity: int = 2,
) -> list[dict[str, object]]:
    """按严重程度筛选发现，保持顺序并返回独立的记录副本。"""
    if not isinstance(findings, list):
        raise TypeError
    if not isinstance(min_severity, int):
        raise TypeError
    if isinstance(min_severity,bool):
        raise TypeError
    if min_severity < 0 or min_severity > 3:
        raise ValueError
    

    for finding in findings:
        if not isinstance(finding,dict):
            raise TypeError
        if len(finding) != 3:
            raise ValueError
        if "id" not in finding or "message" not in finding or "severity" not in finding:
            raise ValueError
        
        id = finding.get("id")
        message = finding.get("message")
        severity = finding.get("severity")

        if not isinstance(id, str) or not isinstance(message, str) or not isinstance(severity,int):
            raise TypeError
        if isinstance(severity,bool):
            raise TypeError
        if severity < 0 or severity > 3:
            raise ValueError
    res = []
    for finding in findings:
        if finding.get("severity") >= min_severity:
            a = finding.copy()
            res.append(a)
    return res
    
    
   