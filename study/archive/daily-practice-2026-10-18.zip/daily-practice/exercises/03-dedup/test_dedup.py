"""deduplicate_findings 的公开测试；仅使用标准库。"""

from copy import deepcopy
import unittest

from dedup import deduplicate_findings


class DeduplicateFindingsTests(unittest.TestCase):
    def test_01_empty_input_returns_new_empty_list(self):
        records = []
        result = deduplicate_findings(records)
        self.assertIsInstance(result, list)
        self.assertEqual(result, [])
        self.assertIsNot(result, records)

    def test_02_single_record_preserves_arbitrary_fields(self):
        marker = object()
        records = [{
            "id": "task-7",
            "severity": "Any type is allowed here",
            "message": None,
            "extra": [1, {"nested": True}],
            "marker": marker,
        }]
        self.assertEqual(deduplicate_findings(records), records)

    def test_03_unique_records_keep_original_order(self):
        records = [{"id": "z"}, {"id": "a"}, {"id": "m"}]
        self.assertEqual(deduplicate_findings(records), records)

    def test_04_first_complete_record_wins(self):
        first = {"id": "same", "message": "First", "only_first": 7}
        later = {"id": "same", "message": "Later", "only_later": 9}
        self.assertEqual(deduplicate_findings([first, later]), [first])

    def test_05_non_adjacent_duplicates_keep_first_occurrence_order(self):
        records = [
            {"id": "b", "message": "First b"},
            {"id": "a", "message": "First a"},
            {"id": "b", "message": "Later b"},
            {"id": "c", "message": "First c"},
            {"id": "a", "message": "Later a"},
        ]
        self.assertEqual(deduplicate_findings(records), [records[0], records[1], records[3]])

    def test_06_ids_are_case_sensitive(self):
        records = [{"id": "Ada"}, {"id": "ada"}, {"id": "ADA"}, {"id": "Ada"}]
        self.assertEqual(deduplicate_findings(records), records[:3])

    def test_07_id_spaces_are_not_normalized(self):
        records = [{"id": "task"}, {"id": " task"}, {"id": "task "}, {"id": "task"}]
        self.assertEqual(deduplicate_findings(records), records[:3])

    def test_08_whitespace_only_ids_are_not_empty_strings(self):
        records = [{"id": " "}, {"id": "\t"}, {"id": "\n"}, {"id": " "}]
        self.assertEqual(deduplicate_findings(records), records[:3])

    def test_09_all_duplicate_ids_keep_only_first_record(self):
        records = [{"id": "same", "value": index} for index in range(10)]
        self.assertEqual(deduplicate_findings(records), [records[0]])

    def test_10_result_list_is_new(self):
        records = [{"id": "a"}, {"id": "b"}]
        result = deduplicate_findings(records)
        self.assertIsInstance(result, list)
        self.assertIsNot(result, records)
        self.assertEqual(result, records)
        result.append({"id": "new"})
        self.assertEqual(records, [{"id": "a"}, {"id": "b"}])

    def test_11_input_records_and_order_are_unchanged(self):
        records = [
            {"id": "b", "details": [1, {"value": "Original"}]},
            {"id": "a", "message": "First"},
            {"id": "b", "message": "Later"},
        ]
        expected = deepcopy(records)
        original_objects = records.copy()
        deduplicate_findings(records)
        self.assertEqual(records, expected)
        for current, original in zip(records, original_objects):
            self.assertIs(current, original)

    def test_12_findings_must_be_a_list(self):
        for records in (None, (), {}, "records", 42, True):
            with self.subTest(input_type=type(records).__name__):
                with self.assertRaises(TypeError):
                    deduplicate_findings(records)

    def test_13_every_item_must_be_a_dictionary(self):
        for item in (None, [], (), "record", 42, True):
            with self.subTest(item_type=type(item).__name__):
                with self.assertRaises(TypeError):
                    deduplicate_findings([{"id": "valid"}, item])

    def test_14_missing_id_is_rejected(self):
        for record in ({}, {"message": "No id"}, {"ID": "Wrong key"}):
            with self.subTest(keys=list(record)):
                with self.assertRaises(ValueError):
                    deduplicate_findings([record])

    def test_15_id_type_and_empty_string_are_validated(self):
        for value in (None, 42, 1.5, True, False, [], {}, b"task"):
            with self.subTest(id_type=type(value).__name__):
                with self.assertRaises(TypeError):
                    deduplicate_findings([{"id": value}])
        with self.assertRaises(ValueError):
            deduplicate_findings([{"id": ""}])

    def test_16_items_after_duplicates_are_still_validated(self):
        invalid_cases = [
            ({}, ValueError),
            ({"id": ""}, ValueError),
            ({"id": 42}, TypeError),
            ({"id": []}, TypeError),
            (None, TypeError),
        ]
        for invalid, error_type in invalid_cases:
            with self.subTest(invalid=invalid, error_type=error_type.__name__):
                records = [{"id": "same", "value": 1}, {"id": "same", "value": 2}, invalid]
                expected = deepcopy(records)
                with self.assertRaises(error_type):
                    deduplicate_findings(records)
                self.assertEqual(records, expected)


if __name__ == "__main__":
    unittest.main()
