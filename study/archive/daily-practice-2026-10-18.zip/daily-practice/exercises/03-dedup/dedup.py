"""按 ID 去重练习；题目见 ../../题目.md#dedup。"""


def deduplicate_findings(
    findings: list[dict[str, object]],
) -> list[dict[str, object]]:
    """按原始 ID 去重，保留首次出现的完整记录及其顺序。"""
    if not isinstance(findings,list):
        raise TypeError
    for finding in findings:
        if not isinstance(finding,dict):
            raise TypeError
        if "id" not in finding:
            raise ValueError
        if not isinstance(finding.get("id"),str):
            raise TypeError
        if len(finding.get("id")) == 0:
            raise ValueError

    seen = set()
    res = []
    for finding in findings:
        if finding.get("id") not in seen:
            seen.add(finding.get("id"))
            res.append(finding)

    return res