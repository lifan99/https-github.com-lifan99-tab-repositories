"""normalize_text 的 16 项公开测试；仅使用标准库。"""

import unittest

from text_validation import normalize_text


class NormalizeTextTests(unittest.TestCase):
    def test_01_normal_text(self):
        self.assertEqual(normalize_text("Review this."), "Review this.")

    def test_02_remove_surrounding_whitespace(self):
        self.assertEqual(normalize_text("\t  review \r\n"), "review")

    def test_03_preserve_internal_spaces(self):
        self.assertEqual(normalize_text("  A  B   C  "), "A  B   C")

    def test_04_preserve_internal_tabs_and_newlines(self):
        self.assertEqual(normalize_text(" \nA\tB\n\nC\r\nD\n "), "A\tB\n\nC\r\nD")

    def test_05_preserve_case_and_punctuation(self):
        self.assertEqual(normalize_text("  Hello, WORLD! (OK?)  "), "Hello, WORLD! (OK?)")

    def test_06_unicode_uses_python_len(self):
        for expected in ("中文🙂", "e\u0301", "审查 café！"):
            with self.subTest(text=expected):
                self.assertEqual(
                    normalize_text(f"\u3000{expected}\u3000", max_chars=len(expected)),
                    expected,
                )
                with self.assertRaises(ValueError):
                    normalize_text(expected, max_chars=len(expected) - 1)

    def test_07_length_equal_to_limit_is_allowed(self):
        self.assertEqual(normalize_text("abc", max_chars=3), "abc")

    def test_08_length_over_limit_is_rejected(self):
        with self.assertRaises(ValueError):
            normalize_text("abcd", max_chars=3)

    def test_09_default_length_limit(self):
        self.assertEqual(normalize_text("x" * 2000), "x" * 2000)
        with self.assertRaises(ValueError):
            normalize_text("x" * 2001)

    def test_10_length_checked_after_trimming(self):
        self.assertEqual(normalize_text(" \t abc \n ", max_chars=3), "abc")

    def test_11_empty_string_is_rejected(self):
        with self.assertRaises(ValueError):
            normalize_text("")

    def test_12_whitespace_only_is_rejected(self):
        for text in (" ", "\t\r\n", "\u3000", " \t\r\n\u3000 "):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    normalize_text(text)

    def test_13_non_string_text_is_rejected(self):
        for text in (None, 42, 1.5, True, [], {}, b"review", object()):
            with self.subTest(text_type=type(text).__name__):
                with self.assertRaises(TypeError):
                    normalize_text(text)

    def test_14_non_integer_max_chars_is_rejected(self):
        for max_chars in (None, 2.0, "2", complex(2, 0), [], {}):
            with self.subTest(max_chars_type=type(max_chars).__name__):
                with self.assertRaises(TypeError):
                    normalize_text("a", max_chars=max_chars)

    def test_15_boolean_max_chars_is_rejected(self):
        for max_chars in (True, False):
            with self.subTest(max_chars=max_chars):
                with self.assertRaises(TypeError):
                    normalize_text("a", max_chars=max_chars)

    def test_16_non_positive_max_chars_is_rejected(self):
        for max_chars in (0, -1, -2000):
            with self.subTest(max_chars=max_chars):
                with self.assertRaises(ValueError):
                    normalize_text("a", max_chars=max_chars)


if __name__ == "__main__":
    unittest.main()
