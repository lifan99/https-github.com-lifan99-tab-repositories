"""文本校验练习；题目见 ../../题目.md#text。"""


def normalize_text(text: str, max_chars: int = 2000) -> str:
    """校验文本与长度上限，返回删除首尾空白后的非空文本。"""
    # ---- 参数校验 ----
    # 只接受字符串，不做隐式类型转换
    if not isinstance(text, str):
        raise TypeError
    # bool 是 int 的子类（isinstance(True, int) 为 True），
    # 需单独排除，否则 True/False 会误通过整数校验
    if not isinstance(max_chars, int) or isinstance(max_chars, bool):
        raise TypeError
    # 正整数校验：0 和负数均非法
    if max_chars <= 0:
        raise ValueError

    # ---- 处理逻辑 ----
    # 删除首尾空白，保留内部空白/换行/大小写/标点
    res = text.strip()
    # 处理后为空，或按 len 计算超长，均拒绝
    if len(res) == 0 or len(res) > max_chars:
        raise ValueError
    return res


    
       
